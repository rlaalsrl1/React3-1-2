import NavBar from "@/app/components/Navbar";

export default async function Foo() {
  return (
    <>
      <NavBar />
      midterm\src\page\About.jsx
    </>
  );
}
