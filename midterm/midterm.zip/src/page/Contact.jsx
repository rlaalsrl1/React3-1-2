export default async function Foo() {
  return (
    <>
      <NavBar />
      midterm/src/page/Contact.jsx
    </>
  );
}
